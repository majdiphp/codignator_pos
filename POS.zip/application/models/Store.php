<?php

class Store extends ActiveRecord\Model {

   public static $table_name = 'zarest_stores';

}
