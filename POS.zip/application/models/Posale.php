<?php

class Posale extends ActiveRecord\Model {

   public static $table_name = 'zarest_posales';
}
