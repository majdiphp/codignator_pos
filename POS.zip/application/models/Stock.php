<?php

class Stock extends ActiveRecord\Model {

   public static $table_name = 'zarest_stocks';

}
