<?php

class Table extends ActiveRecord\Model {

   public static $table_name = 'zarest_tables';
}
