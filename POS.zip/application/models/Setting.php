<?php

class Setting extends ActiveRecord\Model {

   public static $table_name = 'zarest_settings';
}
