<?php

class Combo_item extends ActiveRecord\Model {

   public static $table_name = 'zarest_combo_items';

}
