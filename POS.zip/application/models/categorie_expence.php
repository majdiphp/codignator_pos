<?php

class Categorie_expence extends ActiveRecord\Model {

   public static $table_name = 'zarest_categorie_expences';
}
